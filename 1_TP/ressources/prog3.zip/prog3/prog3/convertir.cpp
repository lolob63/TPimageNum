#include "convertir.h"

convertir::convertir(QObject *parent) : QObject(parent)
{

}
