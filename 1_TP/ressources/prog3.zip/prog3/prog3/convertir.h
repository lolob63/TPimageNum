#ifndef CONVERTIR_H
#define CONVERTIR_H

#include <QObject>

class convertir : public QObject
{
    Q_OBJECT
public:
    explicit convertir(QObject *parent = nullptr);

signals:

};

#endif // CONVERTIR_H
